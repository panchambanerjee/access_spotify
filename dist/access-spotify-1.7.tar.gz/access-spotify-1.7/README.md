This package provides the functionality to download the album art, albumn audio features and audio analysis for any specified artist from Spotify
